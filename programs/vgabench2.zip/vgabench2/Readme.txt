VGABench
--------

This is a simple program for measuring the performance of the VGA graphics library I made for comparison with BGIBench.
No command line parameters are needed, but you must have a VGA compatible card.

Code is included with a binary built with Turbo Pascal 6.0. It should also build with Turbo Pascal 7.0 and maybe even FreePascal.
But should be built for a DOS Real-mode target.

License
-------
VGA bench and the library are public domain, do what you like with them :-)
