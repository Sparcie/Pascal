BGI Bench README
----------------

BGI Bench is a really bog standard testing program for BGI drivers intended for use 
with Borland Turbo Pascal or Turbo C compilers.

I've included the source and a spreadsheet of some results (XLS format) I have from some
basic testing.

I've built this version with Turbo Pascal 6.0, so only BGI files that work with its
graph library will work with this binary. You could however build it with Turbo Pascal 7.0
and use BGIs built for it, although it's graph library is larger and slower.

Basic usage:

BGIBENCH BGIDRIVER gm

where BGIDRIVER is the BGI you want to test and gm is the graphics mode you wish to use.

example:
BGIBENCH CGA 0

If you don't get an error message, (or crash!) it will test the graphics drivers capabilities
and report them after a few minutes.

License
-------
BGIBench is public domain, but the BGI files are still copyright of their original owners.

Most of the BGI files I've included are from Borland which allows(ed) them to be distributed
with compiled programs.

VESA.BGI seems to be one from John Hargraphix (1991?) I'd imagine he has a similar license,
but if it's a problem being here please contact me at my blog: sparcie.wordpress.com